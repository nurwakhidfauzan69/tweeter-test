# Analisis-Sentimen-Twitter-Dengan-Klasifikasi-Na-ve-Bayes
Mengklaskan tweet menjadi positif, negatif dengan penghitungan bobot menggunakan term frequency dengan klasifikasi naive bayes 
- Kodingan ini dibuat oleh Jaka Pratama dan Suhar Prasetyo
- Sentimen analisis ini belum merupakan hasil yang akurat karena pada praproses data masih belum semua dilakukan seperti
  stemming dan normalisasi. 
- Perhitungan bobot term juga hanya masih menggunakan term frequency
- Disini juga menampilkan hasil confussion matriks untuk evaluasi dari klasifikasinya
- Inputan data dapat berupa file excel dengan format csv atau xlxs
- inputan juga dapat berupa twett.
- Data latih pada kodingan ini juga belum proporsional sehingga tingkat akurasi masih belum valid
- Hanya berfungsi dengan tweet yang berbahasa inggris
- Daftar stopword menggunakan bahasa inggris
- Telah dapat menangani kata  negasi  
- Jika ingin menggunakannya dengan data sendiri, maka kodingan harus diubah atau format excel disesuaikan dengan contoh yang 
ada di sini dengan naman file Book1.xlsx

