- ini untuk tugas TKI dengan menghitung nilai dari tf.idf + position dari kalimat.
- Algoritma sudah benar, dengan nilai df hanya yang ada pada dokumen tersebut.
- Default file masi statis, hanya yang ada di corpus(cek saja di corpus)
- nilai default kompresi (50)
- nilai default alpha (0.6)
- nilai default betha (0.4)
- ketika pertama kali sistem di jalankan maka akan mensummary dokumen yang ada di korpus yang paling atas (monggo di buat dinamis)
- hatur nuhun

noted by : Jaka Pratama